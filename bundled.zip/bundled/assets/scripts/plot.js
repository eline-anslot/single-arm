let simon_plot;
let single_arm_plot;

window.MathJax = {
    startup: {
        ready: () => {
            MathJax.startup.defaultReady();
            MathJax.startup.promise.then(() => {
                simon_plot = init_plot("simon");
                interactivity_formula(simon_plot,
                    "outcome-simon",
                    simon_plot.long_time,
                    (data_point) => {
                        interim = constant_interim;
                        return data_point.long_time < interim;
                    },
                    "pulse");
                single_arm_plot = init_plot("single_arm", undefined, marginLeft - 0.5, 0);
                initialise_reactivity(single_arm_plot)
                reducing_trial_duration = init_plot("reducing",
                    generate_data_stopped_recruitment(),
                    width - marginRight + 0.5);

                covariate_adj_plot = init_plot("cov_adj");
                // gsb_plot = init_plot("gsb");
                // interactivity_formula(gsb_plot,
                //     "outcome-gsb",
                //     gsb_plot.long_time,
                //     (data_point) => {
                //         interim = constant_interim;
                //         return data_point.long_time < interim;
                //     },
                //     "pulse");

                proposed_plot = init_plot("proposed");
                interactivity_formula(proposed_plot,
                    "x_gr1",
                    proposed_plot.recruitment_time,
                    (data_point) => {
                        interim = constant_interim;
                        return data_point.recruitment_time < interim && data_point.long_time < interim;
                    },
                    "pulse");
                interactivity_formula(proposed_plot,
                    "s_gr1",
                    proposed_plot.short_time,
                    (data_point) => {
                        interim = constant_interim;
                        return data_point.short_time < interim && data_point.long_time < interim;
                    },
                    "pulse");
                interactivity_formula(proposed_plot,
                    "x_gr1_2",
                    proposed_plot.recruitment_time,
                    (data_point) => {
                        interim = constant_interim;
                        return data_point.recruitment_time < interim && data_point.short_time < interim;
                    },
                    "pulse");
                interactivity_formula(proposed_plot,
                    "s_gr1_2",
                    proposed_plot.short_time,
                    (data_point) => {
                        interim = constant_interim;
                        return data_point.short_time < interim;
                    },
                    "pulse");
                interactivity_formula(proposed_plot,
                    "predY1",
                    proposed_plot.long_time,
                    (data_point) => {
                        interim = constant_interim;
                        return data_point.short_time < interim;
                    },
                    "pulse_ypred");

                proposed_plot2 = init_plot("proposed2");
                interactivity_formula(proposed_plot2,
                    "predY12",
                    proposed_plot2.long_time,
                    (data_point) => {
                        interim = constant_interim;
                        return data_point.short_time < interim;
                    },
                    "pulse_ypred");
                interactivity_formula(proposed_plot2,
                    "x_gr12",
                    proposed_plot2.recruitment_time,
                    (data_point) => {
                        interim = constant_interim;
                        return data_point.recruitment_time < interim && data_point.short_time < interim;
                    },
                    "pulse");
                interactivity_formula(proposed_plot2,
                    "x_gr123",
                    proposed_plot2.recruitment_time,
                    (data_point) => {
                        interim = constant_interim;
                        return data_point.recruitment_time < interim;
                    },
                    "pulse");
                interactivity_formula(proposed_plot2,
                    "predY123",
                    proposed_plot2.long_time,
                    (data_point) => {
                        interim = constant_interim;
                        return data_point.recruitment_time < interim;
                    },
                    "pulse_ypred");

                // proposed_plot3 = init_plot("proposed3");
                // interactivity_formula(proposed_plot3,
                //     "outcome-proposed3",
                //     proposed_plot3.long_time,
                //     (data_point) => {
                //         interim = constant_interim;
                //         return data_point.long_time < interim;
                //     },
                //     "pulse");
                // interactivity_formula(proposed_plot3,
                //     "predY12-2",
                //     proposed_plot3.long_time,
                //     (data_point) => {
                //         interim = constant_interim;
                //         return data_point.short_time < interim;
                //     },
                //     "pulse_ypred");
                // interactivity_formula(proposed_plot3,
                //     "predY12-22",
                //     proposed_plot3.long_time,
                //     (data_point) => {
                //         interim = constant_interim;
                //         return data_point.short_time < interim;
                //     },
                //     "pulse_ypred");
                // interactivity_formula(proposed_plot3,
                //     "predY123-21",
                //     proposed_plot3.long_time,
                //     (data_point) => {
                //         interim = constant_interim;
                //         return data_point.recruitment_time < interim;
                //     },
                //     "pulse_ypred");
                // interactivity_formula(proposed_plot3,
                //     "predY123-22",
                //     proposed_plot3.long_time,
                //     (data_point) => {
                //         interim = constant_interim;
                //         return data_point.recruitment_time < interim;
                //     },
                //     "pulse_ypred");
                // interactivity_formula(proposed_plot3,
                //     "predY123-23",
                //     proposed_plot3.long_time,
                //     (data_point) => {
                //         interim = constant_interim;
                //         return data_point.recruitment_time < interim;
                //     },
                //     "pulse_ypred");
            })
        }
    }
};
script = document.createElement("script");
script.setAttribute("id", "MathJax-script");
script.setAttribute("src", "https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js");
script.setAttribute("async", "");
document.head.appendChild(script);

function init_plot(svg_identifier, data, start_interim_line, opacity) {
    if (data === undefined) {
        data = generate_data();
    }

    if (start_interim_line === undefined) {
        start_interim_line = constant_interim;
    }

    if (opacity === undefined) {
        opacity = constant_opacity;
    }

    // Create the SVG container.
    let svg = d3.select("body")
        .select("section#" + svg_identifier)
        .select("div")
        .select("svg#" + svg_identifier)
        .attr("width", width)
        .attr("height", height);

    add_axis(svg);

    let interim_line = draw_interim_line(svg, start_interim_line);
    let connection_lines = draw_connection_lines(svg, data, opacity);

    let [recruitment_time, recruitment_time_transparent] = draw_shape(svg, data, "recruitment_time", baseline_color, d3.symbolCircle, opacity);
    let [short_time, short_time_transparent] = draw_shape(svg, data, "short_time", short_color, d3.symbolCircle, opacity);
    let [long_time, long_time_transparent] = draw_shape(svg, data, "long_time", long_color, triangle_shape(), opacity);

    let plot = {
        svg, interim_line, recruitment_time, short_time, long_time,
        recruitment_time_transparent, short_time_transparent, long_time_transparent,
        ...connection_lines
    };

    plot = draw_text_field(plot, start_interim_line);
    // initialise_reactivity(plot, data);
    all_interim(plot, start_interim_line, opacity);
    // interactivity_formula(plot, svg_identifier);
    // importMathJax(plot, svg_identifier);
    return plot;
}

function draw_interim_line(svg, interim) {
    let interim_line = svg.append("g")
        .append("line")
        .attr("x1", interim)
        .attr("x2", interim)
        .attr("y1", marginBottom)
        .attr("y2", height - marginTop)
        .attr("stroke", "black")
        .attr("id", "interim_line");
    return interim_line
}

function draw_connection_lines(svg, data, opacity) {
    let connection_lines = svg.append("g")
        .selectAll("line")
        .data(data)
        .enter()
        .append("line")
        .attr("x1", (data_point) => data_point.recruitment_time + radius)
        .attr("x2", (data_point) => data_point.long_time - radius)
        .attr("y1", (_, index) => yScale(index))
        .attr("y2", (_, index) => yScale(index))
        .attr("stroke-width", 1)
        .attr("stroke", "black")
        .attr("class", "connection");
    // transparent
    let transparent_connection_lines = svg.append("g")
        .selectAll("line#transparent")
        .data(data)
        .enter()
        .append("line")
        .attr("x1", (data_point) => data_point.recruitment_time + radius)
        .attr("x2", (data_point) => data_point.long_time - radius)
        .attr("y1", (_, index) => yScale(index))
        .attr("y2", (_, index) => yScale(index))
        .attr("stroke-width", 1)
        .attr("opacity", opacity)
        .attr("stroke", "black")
        .attr("class", "connection")
        .attr("id", "transparent");
    return { transparent_connection_lines, connection_lines };
}

function draw_text_field(plot, interim) {
    plot.text = plot.svg.append("foreignObject")
        .attr("x", marginLeft + 130)
        .attr("y", -10)
        .attr("width", 350)
        .attr("height", 50)
        .append("xhtml:body").attr("style", "margin: 0;");
    set_text(plot, interim);
    return plot;
}

function initialise_reactivity(plot) {
    plot.svg.on("touchmove mousemove", (event) => {
        let interim = d3.pointer(event)[0];
        if (!plot.svg.classed("clicked")) {
            all_interim(plot, interim < marginLeft ? marginLeft - 0.1 : (
                interim > width - marginRight ? width - marginRight : interim
            ))
            set_text(plot, interim);
        };
    });

    plot.svg.on("click", () => on_click(plot));
}

function on_click(plot) {
    if (!plot.svg.classed("clicked")) {
        add_class(plot.svg, "clicked")
        all_interim(plot, constant_interim, 500)
        set_text(plot, constant_interim);
    } else {
        remove_class(plot.svg, "clicked")
    }
}

function set_text(plot, interim) {
    let n_long = plot.recruitment_time
        .filter(data => data.long_time < interim)
        .size();
    let n_short = plot.recruitment_time
        .filter(data => data.short_time < interim)
        .size();
    let n_baseline = plot.recruitment_time
        .filter(data => data.recruitment_time < interim)
        .size();
    plot.text.html(
        "<p style='font-size: large;'><span style='color: " + baseline_color + ";'>n<sub>baseline</sub> = " + n_baseline + "</span>" +
        "&emsp;<span style='color: " + short_color + ";'> n<sub>short</sub> = " + n_short + "</span>" +
        "&emsp;<span style='color: " + long_color + ";'>n<sub>1</sub> = " + n_long + "</span>" +
        "</p>")
}
// function change_interim_with_identifier(plot, identifier, radius, color) {
//     plot.svg.selectAll("circle#" + identifier) // # filters on identifier (id)
//         // while . filters on class
//         .transition()
//         .duration(1000)
//         .attr('r', data_point => data_point[identifier] < parseInt(plot.interim_line.attr("x1")) ? radius : 0)
//         .style('fill', color);
// }

function all_interim(plot, interim, duration) {
    interim = interim === undefined ? plot.interim_line.attr("x1") : interim;
    duration = duration === undefined ? 0 : duration;

    plot.long_time
        .transition()
        .duration(duration)
        .attr('r', data_point => data_point.long_time > interim ? 0 : radius);
    plot.short_time
        .transition()
        .duration(duration)
        .attr('r', data_point => data_point.short_time > interim ? 0 : radius);
    plot.recruitment_time
        .transition()
        .duration(duration)
        .attr('r', data_point => data_point.recruitment_time > interim ? 0 : radius);
    plot.connection_lines
        .transition()
        .duration(duration)
        .attr("stroke-width", data_point => data_point.recruitment_time > interim ? 0 : 1)
        .attr("x1", data_point => data_point.recruitment_time)
        .attr("x2", data_point => data_point.long_time > interim ? interim : data_point.long_time);
    plot.interim_line.transition().duration(duration).attr("x1", interim)
        .attr("x2", interim);
    set_text(plot, interim);
}


function all_interim_cont(plot, interim, duration) {
    interim = interim === undefined ? plot.interim_line.attr("x1") : interim;
    duration = duration === undefined ? 0 : duration;

    plot.long_time
        .transition()
        .duration(duration)
        .attr('r', data_point => data_point.long_time_cont > interim ? 0 : radius);
    plot.short_time
        .transition()
        .duration(duration)
        .attr('r', data_point => data_point.short_time_cont > interim ? 0 : radius);
    plot.recruitment_time
        .transition()
        .duration(duration)
        .attr('r', data_point => data_point.recruitment_time_cont > interim ? 0 : radius);
    plot.connection_lines
        .transition()
        .duration(duration)
        .attr("stroke-width", data_point => data_point.recruitment_time_cont > interim ? 0 : 1)
        .attr("x1", data_point => data_point.recruitment_time_cont)
        .attr("x2", data_point => data_point.long_time_cont > interim ? interim : data_point.long_time_cont);
}

function add_axis(svg) {
    // Declare the x (horizontal position) scale.
    const x = d3.scaleLinear()
        .range([marginLeft, width - marginRight]);


    // Declare the y (vertical position) scale.
    const y = d3.scaleLinear()
        .range([height - marginBottom, marginTop]);

    // Add the x-axis.
    svg.append("g")
        .attr("transform", `translate(0, ${height - marginBottom})`)
        .call(d3.axisBottom(x)
            .tickFormat((domain) => "")
            .ticks(0));

    // X-as label
    svg.append("text")
        .attr("text-anchor", "middle")
        .attr("x", width / 2)
        .attr("y", height - 15)
        .text("Calender time");

    // Add the y-axis.
    svg.append("g")
        .attr("transform", `translate(${marginLeft}, 0)`)
        .call(d3.axisLeft(y)
            .tickFormat((domain) => "")
            .ticks(0));

    // Y-as label
    svg.append("text")
        .attr("text-anchor", "begin")
        .attr("x", 0)
        .attr("y", 15)
        .text("Start recruitment");
}

function draw_shape(svg, data, field, fill_color, interim, opacity, shape) {
    let shapes = svg.selectAll("circle#" + field)
        .data(data)
        .enter()
        .append("circle");
    shapes //.attr("d", d3.symbolsFill(shape))
        .attr('cx', data_point => data_point[field])
        .attr('cy', (_, index) => yScale(index))
        .attr('id', field)
        .attr('class', (data_point) => {
            if (data_point[field] > interim) {
                return "interim";
            } else {
                return "";
            }
        })
        .attr('r', radius)
        .style('fill', fill_color);
    let transparent_shape = svg.selectAll("circle#" + field + "-transparent")
        .data(data)
        .enter()
        .append("circle")
        .attr('cx', data_point => data_point[field])
        .attr('cy', (_, index) => yScale(index))
        .attr('id', field + "-transparent")
        .attr('class', (data_point) => {
            if (data_point[field] > interim) {
                return "interim";
            } else {
                return "";
            }
        })
        .attr('r', radius)
        .style('fill', "black")
        .attr("opacity", opacity);
    return [shapes, transparent_shape];
}

function interactivity_formula(plot, id, item, callable, class2add) {
    y_one = document.getElementById(id);
    if (y_one !== null) {
        y_one.addEventListener("mouseenter", (event) => {
            if (!plot.svg.classed("clicked")) {
                on_click(plot);
            }
            let circles = item.filter(callable);
            classes = circles.attr("class");
            classes = classes === "" ? class2add : (classes + " " + class2add);
            circles.attr("class", classes).attr("r", radius);
        });
        y_one.addEventListener("mouseleave", (event) => {
            classes = item.attr("class").replace(class2add, "");
            item.attr("class", classes);
            all_interim(plot, constant_interim, 500);
        });
    }
}

function triangle_shape() {
    // let color = "green";
    let triangleSize = 25;
    // let verticalTransform = midHeight + Math.sqrt(triangleSize);

    let triangle = d3.symbol()
        .type(d3.symbolTriangle)
        .size(triangleSize)
    return triangle
}

function move_shapes_and_lines(plot, recruitment_time, short_time, long_time, duration) {
    plot.connection_lines.transition().duration(duration)
        .attr("x1", (data_point) => data_point[recruitment_time] + radius)
        .attr("x2", (data_point) => data_point[long_time] - radius)
        .attr("y1", (_, index) => yScale(index))
        .attr("y2", (_, index) => yScale(index))
        .attr("stroke-width", 1)
        .attr("stroke", "black")
        .attr("class", "connection");

    plot.recruitment_time.transition().duration(duration)
        .attr("cx", data_point => data_point[recruitment_time]);
    plot.short_time.transition().duration(duration)
        .attr("cx", data_point => data_point[short_time]);
    plot.long_time.transition().duration(duration)
        .attr("cx", data_point => data_point[long_time]);
}


function move_transparent_shapes_and_lines(plot, recruitment_time, short_time, long_time, duration) {
    plot.transparent_connection_lines.transition().duration(duration)
        .attr("x1", (data_point) => data_point[recruitment_time] + radius)
        .attr("x2", (data_point) => data_point[long_time] - radius)
        .attr("y1", (_, index) => yScale(index))
        .attr("y2", (_, index) => yScale(index))
        .attr("stroke-width", 1)
        .attr("stroke", "black")
        .attr("class", "connection");

    plot.recruitment_time_transparent.transition().duration(duration)
        .attr("cx", data_point => data_point[recruitment_time]);
    plot.short_time_transparent.transition().duration(duration)
        .attr("cx", data_point => data_point[short_time]);
    plot.long_time_transparent.transition().duration(duration)
        .attr("cx", data_point => data_point[long_time]);
}